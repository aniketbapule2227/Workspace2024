package com.springbootdemo.dtospringbootdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DtoSpringbootDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
