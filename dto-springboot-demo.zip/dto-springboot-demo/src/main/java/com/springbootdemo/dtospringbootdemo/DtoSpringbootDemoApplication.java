package com.springbootdemo.dtospringbootdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DtoSpringbootDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DtoSpringbootDemoApplication.class, args);
	}

}
